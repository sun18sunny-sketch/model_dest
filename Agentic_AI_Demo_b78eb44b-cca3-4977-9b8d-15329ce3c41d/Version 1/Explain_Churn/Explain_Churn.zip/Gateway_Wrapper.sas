exec("""
import sys\n
import pandas as pd \n
import traceback\n
sys.path.append("/models/resources/viya/7c25126a-c5ae-4ce0-8537-c4e695387a9c/")\n
import settings_7c25126a_c5ae_4ce0_8537_c4e695387a9c\n
settings_7c25126a_c5ae_4ce0_8537_c4e695387a9c.pickle_path = "/models/resources/viya/7c25126a-c5ae-4ce0-8537-c4e695387a9c/"\n
import call_llm\n
row_by_row = False\n
data = gateway.read_table({'caslib': gateway.args['input_library'], 'name': gateway.args['input_table']})\n
rename_dict = ""\n
if rename_dict:\n
	data = data.rename(columns=rename_dict)\n
scoring_data = data[["userPrompt","API_KEY"]]\n
try:\n
	scored_data = call_llm.scoreModel(**scoring_data)\n
	output = pd.concat([scored_data.reset_index(drop=True), data.reset_index(drop=True)], axis=1)\n
except Exception as e:\n
	sys.stdout.write("An error occurred while scoring the model using batch data processing. Error: " + str(e) + "\\n")\n
	sys.stdout.write(traceback.format_exc())\n
	sys.stdout.write("Retrying using row-by-row data processing for scoring...\\n")\n
	row_by_row = True\n
if row_by_row:\n
	scored_data = pd.DataFrame(columns=["response","llmMetrics"])\n
	for index, row in data.iterrows():\n
		response, llmMetrics = call_llm.scoreModel(**row)\n
		scored_data.loc[index] = [response, llmMetrics]\n
	output = pd.concat([scored_data.reset_index(drop=True), data.reset_index(drop=True)], axis=1)\n
	sys.stdout.write("Note: Batch data processing is recommended for faster scoring of models.\\n")\n
gateway.write_table(output, {'caslib': gateway.args['output_library'], 'name': gateway.args['output_table'], 'promote': True})""")