from openai import AzureOpenAI
import tiktoken
import json
import time
from datetime import datetime

resource= 'Explain Churn'
version= '1.0'
##############################################################################################
# Set LLM model to use and LLM options
##############################################################################################
llmModel= 'gpt-4o-mini'
temperature= 1
top_p= 1

##############################################################################################
# Set the system prompt for the LLM model
##############################################################################################
systemPrompt = """
You are a customer behavior assistant working in the finance industry. Your role is to help customer support associates understand why a specific customer may be at risk of churning, using both model insights and domain knowledge.
You will be given the top 3 drivers of churn from a predictive model, represented by SHAP values. Each driver includes the feature name, the customer's actual value, and the average value for customers who do not churn.
Write a short, human-readable summary explaining why the customer may be leaving. Use simple, empathetic language. Assume the customer support associate does not have deep technical knowledge, but understands banking operations.
Keep the tone professional and direct. Start the explanation with a phrase like:
"It is not surprising that this customer is considering reducing their relationship with us, we see that:"
Then, list the 3 main reasons in bullet format. Frame each reason in plain language based on the difference between the customer's value and the non-churn average, referencing behavior or circumstances that might contribute to dissatisfaction or disengagement.
"""

##############################################################################################
# Execute LLM and return response as well as some metrics
##############################################################################################
def scoreModel(userPrompt, API_KEY):
    "Output: response, llmMetrics"

    response= ""
    llmMetrics= '{}'

    api_key= API_KEY

    # Set up the AzureOpenAI client
    client = AzureOpenAI(
        api_key= api_key,
        api_version="2024-02-01",  # Use the version your deployment supports
        azure_endpoint="https://sasid-ai-123.openai.azure.com/"
    )

    callDate= datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    start= time.time()
    # Define the model and messages
    try:
        response= client.chat.completions.create(
            model=llmModel,
            messages=[
                {"role": "system", "content": systemPrompt},
                {"role": "user", "content": userPrompt}
            ],
            temperature= temperature,
            top_p= top_p 
        )
    except Exception as e:
        prompt_length= 0
        output_length= 0
        response= f"Error calling LLM: {e}"
        return response, llmMetrics
        
    elapsed= time.time() - start

    response= response.choices[0].message.content
    encoding= tiktoken.encoding_for_model(llmModel)
    system_length= len(encoding.encode(systemPrompt))
    prompt_length= len(encoding.encode(userPrompt))
    output_length= len(encoding.encode(response))

    metricsDic={
        "call_date": callDate,
        "system_length": system_length,
        "prompt_length": prompt_length,
        "output_length": output_length,
        "elapsed": elapsed,
        "llm": llmModel,
        "resource": resource,
        "version": version
        }
    llmMetrics= json.dumps(metricsDic)
    
    return response, llmMetrics
