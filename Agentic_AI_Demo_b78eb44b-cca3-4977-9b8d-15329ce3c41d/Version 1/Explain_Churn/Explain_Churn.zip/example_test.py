import os
import os.path
import sys

sys.path.append('/models/resources/viya/7c25126a-c5ae-4ce0-8537-c4e695387a9c/')

import call_llm

import settings_7c25126a_c5ae_4ce0_8537_c4e695387a9c

settings_7c25126a_c5ae_4ce0_8537_c4e695387a9c.pickle_path = '/models/resources/viya/7c25126a-c5ae-4ce0-8537-c4e695387a9c/'

def score_record(userPrompt,API_KEY):
    "Output: response,llmMetrics"
    return call_llm.scoreModel(userPrompt,API_KEY)

print(score_record("",""))
